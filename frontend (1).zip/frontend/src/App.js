// import logo from "./logo.svg";
import "./App.css";

import React, { useState } from "react";
import axios from "axios";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Paper,
  Typography,
  TableHead,
  Button,
  TextField,
} from "@mui/material";

// function App() {
//   const [image, setImage] = useState(null);
//   const [ocrText, setOcrText] = useState('');
//   const [loading, setLoading] = useState(false);

//   const handleImageChange = (e) => {
//     setImage(e.target.files[0]);
//     setOcrText('');
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!image) return;
//     setLoading(true);
//     const formData = new FormData();
//     formData.append('image', image);

//     const res = await fetch('http://localhost:5000/api/ocr', {
//       method: 'POST',
//       body: formData,
//     });
//     const data = await res.json();
//     setLoading(false);
//     setOcrText(data.text || (data.error && 'OCR failed'));
//   };

//   return (
//     <div style={{ maxWidth: 600, margin: 'auto', padding: 20 }}>
//       <h2>OCR Bill/Slip Extractor</h2>
//       <form onSubmit={handleSubmit}>
//         <input type="file" accept="image/*" onChange={handleImageChange} />
//         <button type="submit" disabled={loading || !image}>Extract Text</button>
//       </form>
//       {loading && <p>Processing...</p>}
//       {ocrText && (
//         <div>
//           <h3>Extracted Text:</h3>
//           <pre>{ocrText}</pre>
//         </div>
//       )}
//     </div>
//   );
// }

// export default App;

//important

// import React, { useState } from 'react';
// import './App.css';

// function App() {
//   const [image, setImage] = useState(null);
//   const [ocrText, setOcrText] = useState('');
//   const [fields, setFields] = useState(null);
//   const [loading, setLoading] = useState(false);

//   const handleImageChange = (e) => {
//     setImage(e.target.files[0]);
//     setOcrText('');
//     setFields(null);
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!image) return;
//     setLoading(true);
//     const formData = new FormData();
//     formData.append('image', image);

//     const res = await fetch('http://localhost:5000/api/ocr', {
//       method: 'POST',
//       body: formData,
//     });
//     const data = await res.json();
//     setLoading(false);
//     setOcrText(data.text || (data.error && 'OCR failed'));
//     setFields(data.fields || null);
//   };

//   return (
//     <div style={{ maxWidth: 700, margin: 'auto', padding: 20 }}>
//       <h2>OCR Bill/Slip Extractor</h2>
//       <form onSubmit={handleSubmit}>
//         <input type="file" accept="image/*" onChange={handleImageChange} />
//         <button type="submit" disabled={loading || !image}>Extract Text</button>
//       </form>
//       {loading && <p>Processing...</p>}

//       {fields && (
//         <div>
//           <h3>Extracted Fields:</h3>
//           <table border="1" cellPadding={5} style={{ marginBottom: 20 }}>
//             <thead>
//               <tr>
//                 <th>Date</th>
//                 <th>Time</th>
//                 <th>Location</th>
//                 <th>CODE</th>
//                 <th colSpan={5}>Cassette 2</th>
//                 <th colSpan={5}>Cassette 3</th>
//                 <th colSpan={5}>Cassette 4</th>
//                 <th>TOTAL</th>
//               </tr>
//               <tr>
//                 <th colSpan={4}></th>
//                 <th>CASH</th><th>BEG</th><th>END</th><th>DSP</th><th>ADJ</th>
//                 <th>CASH</th><th>BEG</th><th>END</th><th>DSP</th><th>ADJ</th>
//                 <th>CASH</th><th>BEG</th><th>END</th><th>DSP</th><th>ADJ</th>
//                 <th></th>
//               </tr>
//             </thead>
//             <tbody>
//               <tr>
//                 <td>{fields.date}</td>
//                 <td>{fields.time}</td>
//                 <td>{fields.location}</td>
//                 <td>{fields.code}</td>
//                 <td>{fields.cassette2?.cash}</td>
//                 <td>{fields.cassette2?.beg}</td>
//                 <td>{fields.cassette2?.end}</td>
//                 <td>{fields.cassette2?.dsp}</td>
//                 <td>{fields.cassette2?.adj}</td>
//                 <td>{fields.cassette3?.cash}</td>
//                 <td>{fields.cassette3?.beg}</td>
//                 <td>{fields.cassette3?.end}</td>
//                 <td>{fields.cassette3?.dsp}</td>
//                 <td>{fields.cassette3?.adj}</td>
//                 <td>{fields.cassette4?.cash}</td>
//                 <td>{fields.cassette4?.beg}</td>
//                 <td>{fields.cassette4?.end}</td>
//                 <td>{fields.cassette4?.dsp}</td>
//                 <td>{fields.cassette4?.adj}</td>
//                 <td>{fields.total}</td>
//               </tr>
//             </tbody>
//           </table>
//         </div>
//       )}

//       {ocrText && (
//         <div>
//           <h3>Extracted Raw Text:</h3>
//           <pre>{ocrText}</pre>
//         </div>
//       )}
//     </div>
//   );
// }

// export default App;

//example

// import React, { useState } from 'react';
// import './App.css';

// function App() {
//   const [image, setImage] = useState(null);
//   const [ocrText, setOcrText] = useState('');
//   const [fields, setFields] = useState(null);
//   const [loading, setLoading] = useState(false);

//   const handleImageChange = (e) => {
//     setImage(e.target.files[0]);
//     setOcrText('');
//     setFields(null);
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!image) return;
//     setLoading(true);
//     const formData = new FormData();
//     formData.append('image', image);

//     const res = await fetch('http://localhost:5000/api/ocr', {
//       method: 'POST',
//       body: formData,
//     });
//     const data = await res.json();
//     setLoading(false);
//     setOcrText(data.text || (data.error && 'OCR failed'));
//     setFields(data.fields || null);
//   };

//   return (
//     <div style={{ maxWidth: 700, margin: '1rem', padding: 20 }}>
//       <h2>OCR ATM Slip Extractor</h2>
//       <form onSubmit={handleSubmit}>
//         <input type="file" accept="image/*" onChange={handleImageChange} />
//         <button type="submit" disabled={loading || !image}>Extract Text</button>
//       </form>
//       {loading && <p>Processing...</p>}

//       {fields && (
//         <div>
//           <h3>Extracted Fields:</h3>
//           <table border="1" cellPadding={5} style={{ marginBottom: 20 }}>
//             <thead>
//               <tr>
//                 <th>ATM ID</th>
//                 <th>Location</th>
//                 <th>Date</th>
//                 <th>Time</th>
//                 <th colSpan={5}>Cassette 2 (100rs)</th>
//                 <th colSpan={5}>Cassette 3 (500rs)</th>
//                 <th colSpan={5}>Cassette 4 (200rs)</th>
//                 <th>Total Amount</th>
//                 <th>Rejections</th>
//               </tr>
//               <tr>
//                 <th colSpan={4}></th>
//                 <th>Denom</th><th>Beg</th><th>End</th><th>Notes+</th><th>Amount</th>
//                 <th>Denom</th><th>Beg</th><th>End</th><th>Notes+</th><th>Amount</th>
//                 <th>Denom</th><th>Beg</th><th>End</th><th>Notes+</th><th>Amount</th>
//                 <th></th>
//                 <th></th>
//               </tr>
//             </thead>
//             <tbody>
//               <tr>
//                 <td>{fields.atmId}</td>
//                 <td>{fields.location}</td>
//                 <td>{fields.date}</td>
//                 <td>{fields.time}</td>
//                 <td>{fields.cassette2?.denom}</td>
//                 <td>{fields.cassette2?.beg}</td>
//                 <td>{fields.cassette2?.end}</td>
//                 <td>{fields.cassette2?.notesAdded}</td>
//                 <td>{fields.cassette2?.amount}</td>
//                 <td>{fields.cassette3?.denom}</td>
//                 <td>{fields.cassette3?.beg}</td>
//                 <td>{fields.cassette3?.end}</td>
//                 <td>{fields.cassette3?.notesAdded}</td>
//                 <td>{fields.cassette3?.amount}</td>
//                 <td>{fields.cassette4?.denom}</td>
//                 <td>{fields.cassette4?.beg}</td>
//                 <td>{fields.cassette4?.end}</td>
//                 <td>{fields.cassette4?.notesAdded}</td>
//                 <td>{fields.cassette4?.amount}</td>
//                 <td>{fields.totalAmount}</td>
//                 <td>{fields.rejections}</td>
//               </tr>
//             </tbody>
//           </table>
//         </div>
//       )}

//       {ocrText && (
//         <div>
//           <h3>Extracted Raw Text:</h3>
//           <pre>{ocrText}</pre>
//         </div>
//       )}
//     </div>
//   );
// }

// export default App;

{
  /* <td>{fields.cassette2?.denom}</td>
<td>{fields.cassette2?.beg}</td>
<td>{fields.cassette2?.end}</td>
<td>{fields.cassette2?.notesAdded}</td>
<td>{fields.cassette2?.amount}</td>
...
<td>{fields.totalAmount}</td> */
}

// import { useState } from "react";
// import axios from "axios";
// import {
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableRow,
//   Paper,
//   Typography,
// } from "@mui/material";
// import "./App.css";

// function App() {
//   const [file, setFile] = useState(null);
//   const [data, setData] = useState(null);

//   const upload = async () => {
//     const formData = new FormData();
//     formData.append("image", file);
//     try {
//       const res = await axios.post("http://localhost:5000/api/ocr", formData);
//       setData(res.data.fields);
//     } catch (error) {
//       console.error("Upload error:", error);
//     }
//   };

//   return (
//     <div style={{ padding: "2rem", fontFamily: "Arial" }}>
//       <h1>ATM Slip OCR</h1>
//       <input
//         type="file"
//         accept="image/*"
//         onChange={(e) => setFile(e.target.files[0])}
//       />
//       <button onClick={upload}>Upload & Extract</button>

//       {data && (
//         // <TableContainer
//         //   component={Paper}
//         //   sx={{ maxWidth: 800, margin: "auto", mt: 4 }}
//         // >
//         //   <Typography variant="h6" align="center" sx={{ p: 2 }}>
//         //     ATM Slip Summary
//         //   </Typography>
//         //   <Table>
//         //     <TableBody>
//         //       <TableRow>
//         //         <TableCell>
//         //           <b>ATM ID</b>
//         //         </TableCell>
//         //         <TableCell>{data.atmId}</TableCell>
//         //       </TableRow>
//         //       <TableRow>
//         //         <TableCell>
//         //           <b>Date</b>
//         //         </TableCell>
//         //         <TableCell>{data.date}</TableCell>
//         //       </TableRow>
//         //       <TableRow>
//         //         <TableCell>
//         //           <b>Time</b>
//         //         </TableCell>
//         //         <TableCell>{data.time}</TableCell>
//         //       </TableRow>
//         //       <TableRow>
//         //         <TableCell>
//         //           <b>Location</b>
//         //         </TableCell>
//         //         <TableCell>{data.location}</TableCell>
//         //       </TableRow>
//         //       <TableRow>
//         //         <TableCell>
//         //           <b>RSP Code</b>
//         //         </TableCell>
//         //         <TableCell>{data.code}</TableCell>
//         //       </TableRow>
//         //       <TableRow>
//         //         <TableCell colSpan={2}>
//         //           <b>--- Cassette Info ---</b>
//         //         </TableCell>
//         //       </TableRow>
//         //       {[2, 3, 4].map((num) => {
//         //       const cassette = data[`cassette${num}`];
//         //         return (
//         //           <TableRow key={num}>
//         //             <TableCell>
//         //               <b>Cassette {num}</b>
//         //             </TableCell>
//         //             <TableCell>
//         //               Denom: {cassette?.denom}, BEG: {cassette?.beg}, END:{" "}
//         //               {cassette?.end},
//         //               <br />
//         //               Amount: ₹{cassette?.amount}
//         //             </TableCell>
//         //           </TableRow>
//         //         );
//         //       })}
//         //       <TableRow>
//         //         <TableCell>
//         //           <b>Grand Total</b>
//         //         </TableCell>
//         //         <TableCell>₹{data.totalAmount}</TableCell>
//         //       </TableRow>
//         //     </TableBody>
//         //   </Table>
//         // </TableContainer>
//         <table border="1" cellPadding="10">
//           <tbody>
//             <tr>
//               <td>
//                 <b>ATM ID</b>
//               </td>
//               <td>{data.atmId}</td>
//             </tr>
//             <tr>
//               <td>
//                 <b>Date</b>
//               </td>
//               <td>{data.date}</td>
//             </tr>
//             <tr>
//               <td>
//                 <b>Time</b>
//               </td>
//               <td>{data.time}</td>
//             </tr>
//             <tr>
//               <td>
//                 <b>Location</b>
//               </td>
//               <td>{data.location}</td>
//             </tr>
//             <tr>
//               <td>
//                 <b>RSP Code</b>
//               </td>
//               <td>{data.code}</td>
//             </tr>
//             <tr>
//               <td colSpan="2">
//                 <b>--- Cassette Info ---</b>
//               </td>
//             </tr>
//             {[2, 3, 4].map((num) => {
//               const cassette = data[`cassette${num}`];
//               return (
//                 <TableRow key={num}>
//                   <TableCell>
//                     <b>Cassette {num}</b>
//                   </TableCell>
//                   <TableCell>
//                     Denom: {cassette?.denom}, BEG: {cassette?.beg}, END:{" "}
//                     {cassette?.end},<br />
//                     Amount: ₹{cassette?.amount}
//                   </TableCell>
//                 </TableRow>
//               );
//             })}

//             <tr>
//               <td>
//                 <b>Grand Total</b>
//               </td>
//               <td>₹{data.totalAmount}</td>
//             </tr>
//           </tbody>
//         </table>
//       )}
//     </div>
//   );
// }

// export default App;

// Combined ATM Slip OCR Upload + Indent Form with Material UI

// import React, { useState } from "react";
// import axios from "axios";
// import {
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Typography,
//   Button,
//   TextField,
//   Grid,
// } from "@mui/material";

function App() {
  const [file, setFile] = useState(null);
  const [data, setData] = useState(null);
  const [rows, setRows] = useState([]);
  const [editRowId, setEditRowId] = useState(null);
  const [newRow, setNewRow] = useState({
    atmId: "",
    atmName: "",
    cash100: "",
    cash200: "",
    cash500: "",
  });
  const [showForm, setShowForm] = useState(false);
  // const [file, setFile] = useState(null);
  const [rejectedData, setRejectedData] = useState([]);

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append("image", file);
    

    try {
      const res = await axios.post("http://localhost:5000/api/ocr", formData);
      const data = res.data.fields;

      // ✅ Use END only for calculation
      const endValue = (cassette) => parseInt(cassette?.end || 0);

      const cash100 = endValue(data.cassette2) * 100;
      const cash500 = endValue(data.cassette3) * 500;
      const cash200 = endValue(data.cassette4) * 200;
      const total = cash100 + cash200 + cash500;

      // Assign amount to each cassette
      data.cassette2.amount = cash100;
      data.cassette3.amount = cash500;
      data.cassette4.amount = cash200;
      data.totalAmount = total;

      setData(data); // Store for Typography display

      const newRow = {
        id: rows.length + 1,
        date: data.date || "N/A",
        atmId: data.atmId || "N/A",
        atmName: data.location || "N/A",
        cash100,
        cash200,
        cash500,
        total,
      };

      setRows((prevRows) => [...prevRows, newRow]);
    } catch (error) {
      console.error("Error uploading file:", error);
    }
  };

  const handleInputChange = (event, id, fieldName) => {
    const newValue = event.target.value;
    const updatedRows = rows.map((row) => {
      if (row.id === id) {
        const updatedRow = { ...row, [fieldName]: newValue };
        if (["cash100", "cash200", "cash500"].includes(fieldName)) {
          const total = ["cash100", "cash200", "cash500"].reduce(
            (sum, key) => sum + (parseInt(updatedRow[key]) || 0),
            0
          );
          updatedRow.total = total.toString();
        }
        return updatedRow;
      }
      return row;
    });
    setRows(updatedRows);
  };

  const handleNewRowChange = (event, fieldName) => {
    setNewRow({ ...newRow, [fieldName]: event.target.value });
  };

  const handleAddNewRow = () => {
    const newRowData = {
      id: rows.length + 1,
      date: new Date().toLocaleDateString(),
      ...newRow,
      total: ["cash100", "cash200", "cash500"].reduce(
        (sum, key) => sum + (parseInt(newRow[key]) || 0),
        0
      ),
    };
    setRows([...rows, newRowData]);
    setNewRow({
      atmId: "",
      atmName: "",
      cash100: "",
      cash200: "",
      cash500: "",
    });
  };

  const handleEdit = (id) => setEditRowId(id);
  const handleSave = () => setEditRowId(null);
  const handleDelete = (id) => setRows(rows.filter((row) => row.id !== id));

  const handleSubmit = async () => {
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await axios.post("http://localhost:5000/upload", formData);
      setRejectedData(res.data.rejected);
    } catch (error) {
      console.error("Upload failed", error);
    }
  };
  return (
    <div style={{ padding: "2rem" }}>
      <div style={{ display: "flex", gap: "5rem" }}>
        <div>
          <Typography variant="h4" gutterBottom>
            ATM Slip OCR & Indent Form
          </Typography>

          <input
            type="file"
            accept="image/*"
            onChange={(e) => setFile(e.target.files[0])}
          />
          <Button
            variant="contained"
            color="primary"
            onClick={handleUpload}
            sx={{ m: 2 }}
          >
            Upload & Extract
          </Button>

          {data && (
            <Paper sx={{ p: 2, mb: 4 }}>
              <Typography variant="h6">OCR Data</Typography>
              <Typography>ATM ID: {data.atmId}</Typography>
              <Typography>Date: {data.date}</Typography>
              <Typography>Time: {data.time}</Typography>
              <Typography>Location: {data.location}</Typography>
              {/* <Typography>RSP Code: {data.code}</Typography> */}
              {[2, 3, 4].map((num) => {
                const cassette = data[`cassette${num}`];
                return (
                  <Typography key={num}>
                    Cassette {num}: Denom: {cassette?.denom}, BEG:{" "}
                    {cassette?.beg}, END: {cassette?.end}, Amount: ₹
                    {cassette?.amount}
                  </Typography>
                );
              })}
              <Typography variant="subtitle1">
                Grand Total: ₹{data.totalAmount}
              </Typography>
            </Paper>
          )}
        </div>

        <div style={{ padding: "0" }}>
          <Typography variant="h4" gutterBottom>
            📃 ATM Slip REJECTED Reader
          </Typography>
          {/* <h2>📃 ATM Slip REJECTED Reader</h2> */}
          <input type="file" onChange={(e) => setFile(e.target.files[0])} />
          {/* <button onClick={handleSubmit}>Upload & Extract</button> */}
          <Button
            variant="contained"
            color="primary"
            onClick={handleSubmit}
            sx={{ m: 2 }}
          >
            Upload & Extract
          </Button>

          {rejectedData.length > 0 && (
            <div style={{ marginTop: "1rem" }}>
              <h3>🔍 Rejected Entries</h3>
              <ul>
                {rejectedData.map((line, index) => (
                  <li key={index}>{line}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Date</TableCell>
              <TableCell>ATM ID</TableCell>
              <TableCell>ATM Name</TableCell>
              <TableCell>100</TableCell>
              <TableCell>200</TableCell>
              <TableCell>500</TableCell>
              <TableCell>Total</TableCell>
              {/* <TableCell>Actions</TableCell> */}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => (
              <TableRow key={row.id}>
                <TableCell>{row.date}</TableCell>
                <TableCell>{row.atmId}</TableCell>
                <TableCell>{row.atmName}</TableCell>
                {["cash100", "cash200", "cash500"].map((key) => (
                  <TableCell key={key}>
                    {editRowId === row.id ? (
                      <TextField
                        value={row[key]}
                        onChange={(e) => handleInputChange(e, row.id, key)}
                        variant="standard"
                      />
                    ) : (
                      row[key]
                    )}
                  </TableCell>
                ))}
                <TableCell>{row.total}</TableCell>
                {/* <TableCell>
                  {editRowId === row.id ? (
                    <Button onClick={() => handleSave(row.id)}>Save</Button>
                  ) : (
                    <>
                      <Button onClick={() => handleEdit(row.id)}>Edit</Button>
                      <Button color="error" onClick={() => handleDelete(row.id)}>Delete</Button>
                    </>
                  )}
                </TableCell> */}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
}

export default App;

// import React, { useState } from 'react';
// import './App.css';
// function App() {
//   // Store multiple slips:
//   const [slips, setSlips] = useState([]); // Each slip: { fields, ocrText, filename }
//   const [loading, setLoading] = useState(false);
//   // Handle file input for multiple slips
//   const handleFileChange = async (e) => {
//     const file = e.target.files[0];
//     if (!file) return;
//     setLoading(true);
//     const formData = new FormData();
//     formData.append('image', file);
//     const res = await fetch('http://localhost:5000/api/ocr', {
//       method: 'POST',
//       body: formData,
//     });
//     const data = await res.json();
//     setSlips((prev) => [
//       ...prev,
//       { fields: data.fields || null, ocrText: data.text || '', filename: file.name }
//     ]);
//     setLoading(false);
//   };
//   return (
//     <div style={{ maxWidth: 900, margin: 'auto', padding: 20 }}>
//       <h2>OCR ATM Slip Extractor</h2>
//       <input
//         type="file"
//         accept="image/*"
//         onChange={handleFileChange}
//         disabled={loading}
//         style={{ marginRight: 10 }}
//       />
//       {loading && <span>Processing...</span>}
//       <p>You can upload two slips (before and after cash-in), one after the other.</p>
//       <div style={{ display: 'flex', gap: 40, marginTop: 30 }}>
//         {slips.map((slip, idx) => (
//           <div key={idx} style={{
//             flex: 1,
//             border: '1px solid #aaa',
//             borderRadius: 8,
//             padding: 16,
//             minWidth: 350,
//             background: "#F9F9F9"
//           }}>
//             <h3>Slip {idx === 0 ? 'Before' : 'After'}</h3>
//             <b>Filename:</b> {slip.filename}<br />
//             {slip.fields && (
//               <>
//                 <table border="1" cellPadding={5} style={{ marginBottom: 20, width: "100%" }}>
//                   <thead>
//                     <tr>
//                       <th>ATM ID</th>
//                       <th>Location</th>
//                       <th>Date</th>
//                       <th>Time</th>
//                       <th>100</th>
//                       <th>200</th>
//                       <th>500</th>
//                       <th>Total Amount</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     <tr>
//                       <td>{slip.fields.atmId || slip.fields.ATMId}</td>
//                       <td>{slip.fields.location}</td>
//                       <td>{slip.fields.date}</td>
//                       <td>{slip.fields.time}</td>
//                       <td>{slip.fields.cassette2?.amount}</td>
//                       <td>{slip.fields.cassette4?.amount}</td>
//                       <td>{slip.fields.cassette3?.amount}</td>
//                       <td>{slip.fields.totalAmount}</td>
//                     </tr>
//                   </tbody>
//                 </table>
//               </>
//             )}
//             {slip.ocrText && (
//               <details>
//                 <summary>Show Extracted Raw Text</summary>
//                 <pre style={{ whiteSpace: "pre-wrap" }}>{slip.ocrText}</pre>
//               </details>
//             )}
//           </div>
//         ))}
//       </div>
//       {slips.length === 2 && (
//         <div style={{ marginTop: 30, background: "#E2FFD8", padding: 16, borderRadius: 8 }}>
//           <h3>Cash Added (After - Before):</h3>
//           <ul>
//             <li>100s: {(slips[1].fields.cassette2?.amount || 0) - (slips[0].fields.cassette2?.amount || 0)}</li>
//             <li>200s: {(slips[1].fields.cassette4?.amount || 0) - (slips[0].fields.cassette4?.amount || 0)}</li>
//             <li>500s: {(slips[1].fields.cassette3?.amount || 0) - (slips[0].fields.cassette3?.amount || 0)}</li>
//             <li><b>Total: {(slips[1].fields.totalAmount || 0) - (slips[0].fields.totalAmount || 0)}</b></li>
//           </ul>
//         </div>
//       )}
//     </div>
//   );
// }
// export default App;
